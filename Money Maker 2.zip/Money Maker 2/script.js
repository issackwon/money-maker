// Function to initialize bank value
function initializeBankValue() {
    const bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    // const bank = document.getElementById("bank");
    
    document.getElementById("bank").textContent = bank_val;
    console.log("bank_val: " + bank_val);
    console.log(document.getElementById("bank").textContent);
    bank.textContent = bank_val;

}




// Function to update bank value
function updateBankValue(delta) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;

    delta = delta+ (0.1*parseInt(localStorage.getItem("cursorCountNum")) || 0);
    delta = delta+ (parseInt(localStorage.getItem("grandmaCountNum")) || 0);   
    delta = delta+ (8*parseInt(localStorage.getItem("farmountNum")) || 0);   
    delta = delta+ (47*parseInt(localStorage.getItem("mineCountNum")) || 0);   
    delta = delta+ (260*parseInt(localStorage.getItem("factoryCountNum")) || 0);   
    delta = delta+ (1400*parseInt(localStorage.getItem("bankCountNum")) || 0);   
    delta = delta+ (7800*parseInt(localStorage.getItem("templeCountNum")) || 0);   
    delta = delta+ (44000*parseInt(localStorage.getItem("wizardtowerCountNum")) || 0);   
    delta = delta+ (260000*parseInt(localStorage.getItem("shipmentCountNum")) || 0);   
    delta = delta+ (1600000*parseInt(localStorage.getItem("alchemylabCountNum")) || 0);   
    delta = delta+ (10000000*parseInt(localStorage.getItem("portalcountNum")) || 0);   
    delta = delta+ (65000000*parseInt(localStorage.getItem("timemachineCountNum")) || 0);   

    bank_val += delta;

    const bank = document.getElementById("bank");
    bank.textContent = bank_val;
    localStorage.setItem("bank_val", bank_val);
}



// Function to increment the bank value
function count() {
    updateBankValue(1);
}


// Function to handle cursor count
function cursorcount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let cursorcount = parseInt(localStorage.getItem("cursorCountNum")) || 0;
    let cursormoney = 15 * Math.pow(1.15, cursorcount);
    cursormoney = Math.round(cursormoney);
    localStorage.setItem("cursorMoney", cursormoney);

    // Update DOM for cursormoney
    console.log("cursorcount: " + cursorcount);

    console.log(document.getElementById("cursorCountNum").textContent)
    console.log(document.getElementById("cursorMoney").textContent)

    document.getElementById("cursorCountNum").textContent = cursorcount;
    document.getElementById("cursorMoney").textContent = cursormoney;

    // Update realCps (if needed)
    if (a != 1 && cursormoney <= bank_val) {
        cursorcount++;
        bank_val -= cursormoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for cursormoney
        const cursormoneyText = document.getElementById("cursorMoney");
        cursormoneyText.textContent = cursormoney;
    }

    // Update DOM for cursorcount and cursorMoney
    document.getElementById("cursorCountNum").textContent = cursorcount;
    localStorage.setItem("cursorCountNum", cursorcount);
    document.getElementById("cursorMoney").textContent = cursormoney;
}

function grandmacount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let grandmacount = parseInt(localStorage.getItem("grandmaCountNum")) || 0;
    let grandmamoney = 100 * Math.pow(1.15, grandmacount);
    grandmamoney = Math.round(grandmamoney);
    localStorage.setItem("grandmaMoney", grandmamoney);

    if (a != 1 && grandmamoney <= bank_val) {
        grandmacount++;
        bank_val -= grandmamoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for grandmamoney
        const grandmamoneyText = document.getElementById("grandmaMoney");
        grandmamoneyText.textContent = grandmamoney;
    }

    // Update DOM for grandmacount and grandmaMoney
    document.getElementById("grandmaCountNum").textContent = grandmacount;
    localStorage.setItem("grandmaCountNum", grandmacount);
    document.getElementById("grandmaMoney").textContent = grandmamoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function farmcount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let farmcount = parseInt(localStorage.getItem("farmCountNum")) || 0;
    let farmmoney = 1100 * Math.pow(1.15, farmcount);
    farmmoney = Math.round(farmmoney);
    localStorage.setItem("farmMoney", farmmoney);

    if (a != 1 && farmmoney <= bank_val) {
        farmcount++;
        bank_val -= farmmoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for farmmoney
        const farmmoneyText = document.getElementById("farmMoney");
        farmmoneyText.textContent = farmmoney;
    }

    // Update DOM for farmcount and farmMoney
    document.getElementById("farmCountNum").textContent = farmcount;
    localStorage.setItem("farmCountNum", farmcount);
    document.getElementById("farmMoney").textContent = farmmoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function minecount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let minecount = parseInt(localStorage.getItem("mineCountNum")) || 0;
    let minemoney = 12000 * Math.pow(1.15, minecount);
    minemoney = Math.round(minemoney);
    localStorage.setItem("mineMoney", minemoney);

    if (a != 1 && minemoney <= bank_val) {
        minecount++;
        bank_val -= minemoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for minemoney
        const minemoneyText = document.getElementById("mineMoney");
        minemoneyText.textContent = minemoney;
    }

    // Update DOM for minecount and mineMoney
    document.getElementById("mineCountNum").textContent = minecount;
    localStorage.setItem("mineCountNum", minecount);
    document.getElementById("mineMoney").textContent = minemoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function factorycount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let factorycount = parseInt(localStorage.getItem("factoryCountNum")) || 0;
    let factorymoney = 130000 * Math.pow(1.15, factorycount);
    factorymoney = Math.round(factorymoney);
    localStorage.setItem("factoryMoney", factorymoney);

    if (a != 1 && factorymoney <= bank_val) {
        factorycount++;
        bank_val -= factorymoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for factorymoney
        const factorymoneyText = document.getElementById("factoryMoney");
        factorymoneyText.textContent = factorymoney;
    }

    // Update DOM for factorycount and factoryMoney
    document.getElementById("factoryCountNum").textContent = factorycount;
    localStorage.setItem("factoryCountNum", factorycount);
    document.getElementById("factoryMoney").textContent = factorymoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function bankcount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let bankcount = parseInt(localStorage.getItem("bankCountNum")) || 0;
    let bankmoney = 1400000 * Math.pow(1.15, bankcount);
    bankmoney = Math.round(bankmoney);
    localStorage.setItem("bankMoney", bankmoney);

    if (a != 1 && bankmoney <= bank_val) {
        bankcount++;
        bank_val -= bankmoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for bankmoney
        const bankmoneyText = document.getElementById("bankMoney");
        bankmoneyText.textContent = bankmoney;
    }

    // Update DOM for bankcount and bankMoney
    document.getElementById("bankCountNum").textContent = bankcount;
    localStorage.setItem("bankCountNum", bankcount);
    document.getElementById("bankMoney").textContent = bankmoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function templecount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let templecount = parseInt(localStorage.getItem("templeCountNum")) || 0;
    let templemoney = 20000000 * Math.pow(1.15, templecount);
    templemoney = Math.round(templemoney);
    localStorage.setItem("templeMoney", templemoney);

    if (a != 1 && templemoney <= bank_val) {
        templecount++;
        bank_val -= templemoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for templemoney
        const templemoneyText = document.getElementById("templeMoney");
        templemoneyText.textContent = templemoney;
    }

    // Update DOM for templecount and templeMoney
    document.getElementById("templeCountNum").textContent = templecount;
    localStorage.setItem("templeCountNum", templecount);
    document.getElementById("templeMoney").textContent = templemoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function wizardtowercount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let wizardtowercount = parseInt(localStorage.getItem("wizardtowerCountNum")) || 0;
    let wizardtowermoney = 330000000 * Math.pow(1.15, wizardtowercount);
    wizardtowermoney = Math.round(wizardtowermoney);
    localStorage.setItem("wizardtowerMoney", wizardtowermoney);

    if (a != 1 && wizardtowermoney <= bank_val) {
        wizardtowercount++;
        bank_val -= wizardtowermoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for wizardtowermoney
        const wizardtowermoneyText = document.getElementById("wizardtowerMoney");
        wizardtowermoneyText.textContent = wizardtowermoney;
    }

    // Update DOM for wizardtowercount and wizardtowerMoney
    document.getElementById("wizardtowerCountNum").textContent = wizardtowercount;
    localStorage.setItem("wizardtowerCountNum", wizardtowercount);
    document.getElementById("wizardtowerMoney").textContent = wizardtowermoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function shipmentcount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let shipmentcount = parseInt(localStorage.getItem("shipmentCountNum")) || 0;
    let shipmentmoney = 5100000000 * Math.pow(1.15, shipmentcount);
    shipmentmoney = Math.round(shipmentmoney);
    localStorage.setItem("shipmentMoney", shipmentmoney);

    if (a != 1 && shipmentmoney <= bank_val) {
        shipmentcount++;
        bank_val -= shipmentmoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for shipmentmoney
        const shipmentmoneyText = document.getElementById("shipmentMoney");
        shipmentmoneyText.textContent = shipmentmoney;
    }

    // Update DOM for shipmentcount and shipmentMoney
    document.getElementById("shipmentCountNum").textContent = shipmentcount;
    localStorage.setItem("shipmentCountNum", shipmentcount);
    document.getElementById("shipmentMoney").textContent = shipmentmoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function alchemylabcount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let alchemylabcount = parseInt(localStorage.getItem("alchemylabCountNum")) || 0;
    let alchemylabmoney = 75000000000 * Math.pow(1.15, alchemylabcount);
    alchemylabmoney = Math.round(alchemylabmoney);
    localStorage.setItem("alchemylabMoney", alchemylabmoney);

    if (a != 1 && alchemylabmoney <= bank_val) {
        alchemylabcount++;
        bank_val -= alchemylabmoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for alchemylabmoney
        const alchemylabmoneyText = document.getElementById("alchemylabMoney");
        alchemylabmoneyText.textContent = alchemylabmoney;
    }

    // Update DOM for alchemylabcount and alchemylabMoney
    document.getElementById("alchemylabCountNum").textContent = alchemylabcount;
    localStorage.setItem("alchemylabCountNum", alchemylabcount);
    document.getElementById("alchemylabMoney").textContent = alchemylabmoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function portalcount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let portalcount = parseInt(localStorage.getItem("portalCountNum")) || 0;
    let portalmoney = 1000000000000 * Math.pow(1.15, portalcount);
    portalmoney = Math.round(portalmoney);
    localStorage.setItem("portalMoney", portalmoney);

    if (a != 1 && portalmoney <= bank_val) {
        portalcount++;
        bank_val -= portalmoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for portalmoney
        const portalmoneyText = document.getElementById("portalMoney");
        portalmoneyText.textContent = portalmoney;
    }

    // Update DOM for portalcount and portalMoney
    document.getElementById("portalCountNum").textContent = portalcount;
    localStorage.setItem("portalCountNum", portalcount);
    document.getElementById("portalMoney").textContent = portalmoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function timemachinecount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let timemachinecount = parseInt(localStorage.getItem("timemachineCountNum")) || 0;
    let timemachinemoney = 14000000000000 * Math.pow(1.15, timemachinecount);
    timemachinemoney = Math.round(timemachinemoney);
    localStorage.setItem("timemachineMoney", timemachinemoney);

    if (a != 1 && timemachinemoney <= bank_val) {
        timemachinecount++;
        bank_val -= timemachinemoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for timemachinemoney
        const timemachinemoneyText = document.getElementById("timemachineMoney");
        timemachinemoneyText.textContent = timemachinemoney;
    }

    // Update DOM for timemachinecount and timemachineMoney
    document.getElementById("timemachineCountNum").textContent = timemachinecount;
    localStorage.setItem("timemachineCountNum", timemachinecount);
    document.getElementById("timemachineMoney").textContent = timemachinemoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

// Initialize bank value on window load
window.onload = function () {
    console.log("window loaded");
    initializeBankValue();
    cursorcount(1);
    grandmacount(1);
    farmcount(1);
    minecount(1);
    factorycount(1);
    bankcount(1);
    templecount(1);
    wizardtowercount(1);
    shipmentcount(1);
    alchemylabcount(1);
    portalcount(1);
    timemachinecount(1);
    
};