document.addEventListener('DOMContentLoaded', function () {
    const targetButton = document.getElementById('targetButton');
    const intervalTime = 1000; // 클릭 간격을 밀리초 단위로 설정 (여기서는 1000ms = 1초)

    // 주기적으로 클릭 이벤트를 발생시키는 함수
    function autoClick() {
        targetButton.click();
    }

    // setInterval을 사용하여 주기적으로 autoClick 함수 호출
    setInterval(autoClick, intervalTime);
});
